<?php
/*koneksi ke database*/
$DB = new mysqli("localhost", "camieux", "viper666", "latsbdlweek9"); //sesuaikan
if (mysqli_connect_errno()) {
    echo ("gagal koneksi, pesan kesalahan: " . mysqli_connect_error());
    exit();
}

$varData = json_decode($_GET['parData']);
$varJmlData = sizeof($varData);
for ($varIndex = 0; $varIndex < $varJmlData; $varIndex++) {
    echo "nim: " . $varData[$varIndex]->nim . "<br/>";
    echo "nama: " . $varData[$varIndex]->nama . "<br/>";
    echo "kd prodi: " . $varData[$varIndex]->kdProdi . "<br/>";
    echo "<br/>";
}
echo"cek db". "<br/>";
echo "Jumlah Data: " . sizeof($varData);
/*query simpan data ke tabel*/
$simpanData = $DB->prepare("insert into produk(nim, nama,
kdProdi) values (?, ?, ?)");
$simpanData->bind_param('sss', $varKode, $varNama, $varHarga);
$varIndex = 0;
while ($varIndex < $varJmlData) {
    $varKode = $varData[$varIndex]->nim;
    $varNama = $varData[$varIndex]->nama;
    $varHarga = $varData[$varIndex]->kdProdi;
    if ($simpanData->execute()) {
        echo "<br/>Data berhasil disimpan";
        header("location:index.html");
    } else {
        die("<br/>isi data gagal: " . htmlspecialchars($simpanData->error));
    };
    $varIndex++;
}
